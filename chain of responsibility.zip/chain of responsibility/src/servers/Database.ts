import permissionTypes from "./permissionTypes";

interface DatabaseItem{
    email : String;
    password : String;
    permission : permissionTypes;
}

const Database : DatabaseItem[] =[
    {
        email: "teste@admin.br",
        password: "123123",
        permission: permissionTypes.ADMIN
    },
    {
        email: "teste@user.br",
        password: "456456",
        permission: permissionTypes.USER
    }
];

export default Database;