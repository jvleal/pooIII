enum permissionTypes{
    USER,
    ADMIN
}

export default permissionTypes;