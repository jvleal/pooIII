import Middleware from "./Middleware";

export default class CheckWeakPaddword extends Middleware{
    public check(email: String, password: String): boolean {
        if(password.length < 6){
            console.log("Senha fraca!");
            return false;
        }
        return this.checkNext(email,password);
    }

}