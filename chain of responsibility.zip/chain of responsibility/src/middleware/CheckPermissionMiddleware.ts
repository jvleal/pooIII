import Database from "../servers/Database";
import permissionTypes from "../servers/permissionTypes";
import Middleware from "./Middleware";

export default class CheckPermissionMiddleware extends Middleware{
   
    public check(email: string, password: string): boolean {
       console.log("Verificando Permissão")
        const users = Database.filter(
            item => item.email === email
        );
        if(!users.length){
            console.error("Email não cadastrado!");
            return false;
        }
        if(users[0].permission === permissionTypes.ADMIN){
            console.log("Seja bem vindo Administrador!");
            return true;
        }else{
            console.log("Seja bem vindo Usuário!");
        }

        return this.checkNext(email,password);
    }
}