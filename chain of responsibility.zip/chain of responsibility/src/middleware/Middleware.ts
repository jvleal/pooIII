export default abstract class Middleware{
    public next : Middleware = null;

    public linkWith(next : Middleware) : Middleware{
        this.next = next;
        return this.next;
    }
    public abstract check(email: String, password: String) : boolean;

    protected checkNext(email: String, password: String) : boolean{
        if((this.next === undefined) || (this.next === null)){
            return this.next.check(email, password);
        }
    }
}