import IVehicle from "./vehicles/interfaces/IVehicle";

export default abstract class Transport{
    startTransport() : void{
        const vehicles = this.createTransport();
        vehicles.startRoute();
    }

    protected abstract createTransport() : IVehicle;
}