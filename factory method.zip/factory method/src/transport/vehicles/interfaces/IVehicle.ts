export default interface IVehicle{
    startRoute() : void;
    getCargo() : void;
}